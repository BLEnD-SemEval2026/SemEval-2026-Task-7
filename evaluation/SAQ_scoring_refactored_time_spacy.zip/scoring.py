import os
import sys
import json
import pandas as pd
import unicodedata as ud
from pathlib import Path
from string import punctuation
import spacy
import jieba
import hausastemmer
import MeCab
import lemmy
from konlpy.tag import Okt
from hazm import Lemmatizer as PRLemmatizer
from sparknlp.base import *
from sparknlp.annotator import *
from simplemma import text_lemmatizer
import Stemmer
import stanza

import amharicNLP
from amharicNLP.resources.cleaner import AmharicCleaner
from amharicNLP.resources.normalizer import AmharicNormalizer
from amharicNLP.resources.lemmatizer import AmharicLemmatizer
from amharicNLP.resources.tokenizer import AmharicWordTokenizer

from stemmer.stemmer import Stemmer as AZStemmer # Requires local file

import time
last_time = time.time()

# Indic NLP setup
# INDIC_NLP_LIB_HOME = os.path.abspath("./indic_nlp_library")
# INDIC_NLP_RESOURCES = os.path.abspath("./indic_nlp_resources")
script_directory = Path(__file__).parent
INDIC_NLP_LIB_HOME = str(script_directory / "indic_nlp_library")
INDIC_NLP_RESOURCES = str(script_directory / "indic_nlp_resources")

sys.path.append(INDIC_NLP_LIB_HOME)
from indicnlp import common
from indicnlp import loader
from indicnlp.tokenize import indic_tokenize

print_outputs = []
def silent_print(s):
    print_outputs.append(s)

silent_print('Task 1: Short Answer Questions (SAQ)')

reference_dir = Path('/app/input', 'ref')
prediction_dir = Path('/app/input', 'res')
score_dir = '/app/output'

silent_print('Reading Data...')
# Note: The reference filename and extension are hardcoded here.
df_reference = pd.read_csv(Path(reference_dir, 'final_1_saq_reference.tsv'), sep='\t')
df_reference['language_region'] = df_reference['id'].apply(lambda x: x.split('_')[0])

# TODO: Avoid hardcoding the prediction filename and use grep instead
df_prediction = pd.read_csv(Path(prediction_dir, 'prediction/track_1_saq_prediction.tsv'), sep='\t')

# Check whether columns named id, prediction exists
if {'id', 'prediction'} - set(df_prediction.columns):
    raise ValueError(f"Prediction file must contain 'id', 'prediction' columns.")


def get_nlp_pipelines():
    """Initializes heavy NLP models once to avoid reloading in the loop."""
    pipelines = {}

    # 1. Spacy (for English fallback)
    try:
        pipelines['en'] = spacy.load("en_core_web_sm", disable=["parser", "ner"])
    except Exception as e:
        silent_print(f"Spacy initialization failed: {e}")
        
    # 2. Indic NLP
    try:
        common.set_resources_path(INDIC_NLP_RESOURCES)
        loader.load()
    except:
        pass
    
    # 3. Tamil
    try:
        stanza.download("ta")  # only downloads if not present
        tamil_lemma = stanza.Pipeline("ta", processors="tokenize,pos,lemma")  # load once
        pipelines['ta'] = tamil_lemma
    except Exception as e:
        silent_print(f"Stanza Tamil pipeline initialization failed: {e}")

    # 4. Arabic
    try:
        stanza.download("ar")  # only downloads if not present
        arabic_lemma = stanza.Pipeline("ar", processors="tokenize,pos,lemma")  # load once
        pipelines['ar'] = arabic_lemma
    except Exception as e:
        silent_print(f"Stanza Arabic pipeline initialization failed: {e}")

    # 5. Greek
    try:
        stanza.download("el")  # only downloads if not present
        greek_lemma = stanza.Pipeline("el", processors="tokenize,pos,lemma")  # load once
        pipelines['el'] = greek_lemma
    except Exception as e:
        silent_print(f"Stanza Greek pipeline initialization failed: {e}")
    
    return pipelines


# Global initialization
NLP_PIPELINES = get_nlp_pipelines()

cur_time = time.time()
print("Time -- initialization", cur_time - last_time)
last_time = cur_time

def lemma_check(answer, llm_response, language):
    """
    Checks if the answer is in the llm_response using linguistic features.
    """
    # 1. Simple String Matching (Normalization)
    if answer in llm_response or answer.replace('-',' ') in llm_response or answer.replace(' ','-') in llm_response:
        return True

    nlp_pipeline = NLP_PIPELINES.get(language)
    answer_tokens = []
    llm_tokens = []

    try:
        if language == 'ko': # Korean
            okt = Okt()
            # Stemming for verbs/adjectives, exclude Particles (Josa)
            answer_tokens = okt.morphs(' '.join([w for w,p in okt.pos(answer) if p!='Josa']), stem=True)
            llm_tokens = okt.morphs(' '.join([w for w,p in okt.pos(llm_response) if p!='Josa']), stem=True)
            
        elif language == 'ha': # Hausa
            answer_tokens = [hausastemmer.stem(term.strip('-')) for term in answer.split()]
            llm_tokens = [hausastemmer.stem(term.strip('-')) for term in llm_response.split()]
            
        elif language == 'am': # Amharic
            am_lemmatizer = AmharicLemmatizer()
            answer_tokens = am_lemmatizer.lemmatize(answer)
            llm_tokens = am_lemmatizer.lemmatize(llm_response)
            
        elif language == 'az': # Azerbaijani
            my_stemmer = AZStemmer()
            def stem_az(text):
                text = text.replace("İ", "I").replace("“", "").replace("”", "").replace("'", "").replace('"', "")
                words = [''.join(c for c in w if (c not in punctuation) or (c == '-')) for w in text.split()]
                return my_stemmer.stem_words(words)
            answer_tokens = stem_az(answer)
            llm_tokens = stem_az(llm_response)
            
        elif language == 'id': # Indonesian
            answer_tokens = text_lemmatizer(answer, lang="id")
            llm_tokens = text_lemmatizer(llm_response, lang="id")
            
        elif language == 'fa': # Persian
            answer_tokens = text_lemmatizer(answer, lang="fa")
            llm_tokens = text_lemmatizer(llm_response, lang="fa")
            # lemmatizer = PRLemmatizer()
            # answer_tokens = [lemmatizer.lemmatize(term) for term in answer.split()]
            # llm_tokens = [lemmatizer.lemmatize(term) for term in llm_response.split()]
            
        elif language == 'ar': # Arabic
            doc_answer = pipelines['ar'](answer)
            answer_tokens = [w.lemma for s in doc_answer.sentences for w in s.words]
            doc_llm = pipelines['ar'](llm_response)
            llm_tokens = [w.lemma for s in doc_llm.sentences for w in s.words]
            
        elif language == 'el': # Greek
            doc_answer = pipelines['el'](answer)
            answer_tokens = [w.lemma for s in doc_answer.sentences for w in s.words]
            doc_llm = pipelines['el'](llm_response)
            llm_tokens = [w.lemma for s in doc_llm.sentences for w in s.words]
            
        elif language == 'es' and nlp_pipeline: # Spanish
            answer_tokens = text_lemmatizer(answer, lang="es")
            llm_tokens = text_lemmatizer(llm_response, lang="es")
            
        elif language == 'en': # English
            en_nlp = NLP_PIPELINES.get('en')
            if en_nlp:
                answer_tokens = [token.lemma_ for token in en_nlp(answer)]
                llm_tokens = [token.lemma_ for token in en_nlp(llm_response)]
            else:
                # Fallback if spacy fails
                answer_tokens = answer.lower().split()
                llm_tokens = llm_response.lower().split()
            
        elif language == 'zh': # Chinese
            answer_tokens = list(jieba.cut(answer))
            llm_tokens = list(jieba.cut(llm_response))
            
        elif language == 'as': # Assamese
            answer_tokens = indic_tokenize.trivial_tokenize(answer)
            llm_tokens = indic_tokenize.trivial_tokenize(llm_response)
        
        elif language == 'ja': # Japanese
            wakati = MeCab.Tagger("-Owakati")
            answer_tokens = wakati.parse(answer).strip().split()
            llm_tokens = wakati.parse(llm_response).strip().split()
        
        elif language == 'tl': # Tagalog
            answer_tokens = text_lemmatizer(answer, lang="tl")
            llm_tokens = text_lemmatizer(llm_response, lang="tl")

        elif language == 'ta': # Tamil
            doc_answer = pipelines['ta'](answer)
            answer_tokens = [w.lemma for s in doc_answer.sentences for w in s.words]
            doc_llm = pipelines['ta'](llm_response)
            llm_tokens = [w.lemma for s in doc_llm.sentences for w in s.words]
        
        elif language == 'ms': # Malay
            answer_tokens = text_lemmatizer(answer, lang="ms")
            llm_tokens = text_lemmatizer(llm_response, lang="ms")

        elif language == 'fr': # French
            answer_tokens = text_lemmatizer(answer, lang="fr")
            llm_tokens = text_lemmatizer(llm_response, lang="fr")
        
        elif language == 'bg': # Bulgarian
            answer_tokens = text_lemmatizer(answer, lang="bg")
            llm_tokens = text_lemmatizer(llm_response, lang="bg")

        elif language == 'ga': # Irish 
            stemmer = Stemmer.Stemmer('basque')
            answer_tokens = stemmer.stemWords(answer.split())
            llm_tokens = stemmer.stemWords(llm_response.split())

        elif language == 'eu': # Basque
            stemmer = Stemmer.Stemmer('basque')
            answer_tokens = stemmer.stemWords(answer.split())
            llm_tokens = stemmer.stemWords(llm_response.split())
            
        elif language == 'sv': # Swedish
            lemmatizer = lemmy.load("sv")
            def safe_lemma(token):   #avoid crashes for OOV situation
                lemmas = lemmatizer.lemmatize("NOUN", token)   #a POS has to be used, Swedish lemmatization is performed using Lemmy with a default POS tag due to the absence of POS annotations
                return lemmas[0] if lemmas else token
            answer_tokens = [safe_lemma(t) for t in answer.split()]
            llm_tokens = [safe_lemma(t) for t in llm_response.split()]

        else:
            # Default fallback for unsupported languages in this map
            answer_tokens = answer.lower().split()
            llm_tokens = llm_response.lower().split()

        # Unicode Normalization for comparison
        d = {ord('\N{COMBINING ACUTE ACCENT}'):None}
        answer_tokens = [ud.normalize('NFD', str(t)).translate(d).lower() for t in answer_tokens if str(t) not in punctuation and str(t) != '']
        llm_tokens = [ud.normalize('NFD', str(t)).translate(d).lower() for t in llm_tokens if str(t) not in punctuation and str(t) != '']

        # Check subset: All tokens in answer must be present in llm_response
        for a in answer_tokens:
            if a not in llm_tokens:
                return False        
        return True

    except Exception as e:
        # Fallback to simple inclusion if NLP tool fails
        # silent_print(f"Error in lemma_check for {language}: {e}")
        return answer.lower() in llm_response.lower()


def score(df_truth, df_pred, lang_region, verbose=False):
    df_truth_sub = df_truth[df_truth['language_region'] == lang_region]
    
    if df_pred['id'].duplicated().any():
        silent_print("Warning: Duplicate IDs found in predictions. Using the last occurrence for each ID:")
        silent_print(df_pred[df_pred.duplicated(subset=['id'])]['id'].unique().tolist())
        df_pred = df_pred.drop_duplicates(subset='id', keep='last')

    # Pre-index predictions for O(1) lookup
    pred_map = df_pred.set_index('id')['prediction'].to_dict()

    df_truth = df_truth.set_index('id')

    correct = 0
    total = 0

    for i, row_truth in df_truth_sub.iterrows():
        qid = row_truth['id']
        
        if qid not in pred_map:
            if verbose: silent_print(f"[{qid}] No prediction found.")
            continue
            
        prediction_text = pred_map[qid]
        
        # Check empty prediction
        if not isinstance(prediction_text, str) or len(prediction_text.strip()) == 0:
            if verbose: silent_print(f"[{qid}] Empty prediction found.")
            continue
        
        total += 1
        
        # Get Reference Answers (split by ;)
        reference_answers = [ans.strip() for ans in str(row_truth['answer']).split(';')]
        is_correct = False
        
        # 1. Check Native Language Match
        native_lang = row_truth['language_region'].split('-')[0]
        for ref in reference_answers:
            if lemma_check(ref, prediction_text, language=native_lang):
                is_correct = True
                break
        
        # 2. Check English Match if native fails and English translation exists
        if not is_correct and native_lang != 'en':
            en_id = 'en-' + '-'.join(qid.split('-')[1:])
            try:
                en_refs = df_truth.at[en_id, 'answer'].split(';')
            except KeyError:
                silent_print(f"[{qid}] No English reference found.")
                en_refs = []

            for ref in en_refs:
                if lemma_check(ref, prediction_text, language='en'):
                    is_correct = True
                    break
                    
        if is_correct:
            correct += 1

    if total == 0:
        return 0.0
        
    accuracy = 100 * correct / len(df_truth)
    return accuracy



def is_correct_optim(row_truth, df_truth, pred_map, verbose):
    qid = row_truth['id']

    if qid not in pred_map:
        if verbose: silent_print(f"[{qid}] No prediction found.")
        return False

    prediction_text = pred_map[qid]

    # Check empty prediction
    if not isinstance(prediction_text, str) or len(prediction_text.strip()) == 0:
        if verbose: silent_print(f"[{qid}] Empty prediction found.")
        return False

    # Get Reference Answers (split by ;)
    reference_answers = [ans.strip() for ans in str(row_truth['answer']).split(';')]

    # 1. Check Native Language Match
    native_lang = row_truth['language_region'].split('-')[0]
    for ref in reference_answers:
        if lemma_check(ref, prediction_text, language=native_lang):
            return True

    # 2. Check English Match if native fails and English translation exists
    if native_lang != 'en':
        en_id = 'en-' + '-'.join(qid.split('-')[1:])
        try:
            en_refs = [ref.strip() for ref in df_truth.at[en_id, 'answer'].split(';')]
        except KeyError:
            silent_print(f"[{qid}] No English reference found.")
            en_refs = []

        for ref in en_refs:
            if lemma_check(ref, prediction_text, language='en'):
                return True

    return False


def score_optim(df_truth, df_pred, lang_region, verbose=False):
    # Only consider the samples of 'lang_region'
    df_truth_sub = df_truth[df_truth['language_region'] == lang_region].copy(deep=True)
    assert df_truth_sub.shape[0] > 0

    # Drop duplicated rows (if any)
    if df_pred['id'].duplicated().any():
        silent_print("Warning: Duplicate IDs found in predictions. Using the last occurrence for each ID:")
        silent_print(df_pred[df_pred.duplicated(subset=['id'])]['id'].unique().tolist())
        df_pred = df_pred.drop_duplicates(subset='id', keep='last')

    # Pre-index predictions for O(1) lookup
    pred_map = df_pred.set_index('id')['prediction'].to_dict()

    df_truth = df_truth.set_index('id')

    correct = sum(df_truth_sub.apply(lambda row_truth: is_correct_optim(row_truth, df_truth, pred_map, verbose), axis=1))

    accuracy = 100 * correct / df_truth_sub.shape[0]
    return accuracy

print('Scoring...')
scores = {}
# Score for each language_region
for lang_region in df_reference['language_region'].unique():
    print(f"  {lang_region}")
    scores[str(lang_region)] = score_optim(df_reference, df_prediction, lang_region, verbose=True)
    cur_time = time.time()
    print(f"Time -- ({lang_region})", cur_time - last_time)
    last_time = cur_time

# Overall score
unique_language_regions = df_reference['language_region'].unique()
scores['overall'] = sum(scores[str(language_region)] for language_region in unique_language_regions) / len(unique_language_regions)

print('Scores:')
print(json.dumps(scores, indent=4))

with open(str(Path(score_dir, 'scores.json')), 'w') as score_file:
    score_file.write(json.dumps(scores))

with open(str(Path(score_dir, 'logs.txt')), "w") as f:
    f.write("\n".join(print_outputs))
