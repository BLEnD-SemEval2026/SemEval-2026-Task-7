script Package
==============

:mod:`indic_scripts` Module
---------------------------

.. automodule:: indicnlp.script.indic_scripts
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`english_script` Module
---------------------------

.. automodule:: indicnlp.script.english_script
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`phonetic_sim` Module
---------------------------

.. automodule:: indicnlp.script.phonetic_sim
    :members: 
    :undoc-members:
    :show-inheritance: