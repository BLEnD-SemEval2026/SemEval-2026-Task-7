syllable Package
==============

:mod:`syllabifier` Module
---------------------------

.. automodule:: indicnlp.syllable.syllabifier
    :members:
    :undoc-members:
    :show-inheritance:

