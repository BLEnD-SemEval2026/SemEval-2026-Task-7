normalize Package
=================

:mod:`indic_normalize` Module
-----------------------------

.. automodule:: indicnlp.normalize.indic_normalize
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: indicnlp.normalize.indic_normalize.
    :members:
    :undoc-members:
    :show-inheritance:
