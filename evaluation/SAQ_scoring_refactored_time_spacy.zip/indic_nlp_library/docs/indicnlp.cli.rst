cli Package
=============

:mod:`cliparser` Module
--------------------------------

.. automodule:: indicnlp.cli.cliparser
    :members:
    :undoc-members:
    :show-inheritance:

