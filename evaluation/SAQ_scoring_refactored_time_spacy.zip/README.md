```bash
git clone https://github.com/aznlp-disc/stemmer.git
git clone https://github.com/anoopkunchukuttan/indic_nlp_library.git
git clone https://github.com/anoopkunchukuttan/indic_nlp_resources.git
```