import json
import pandas as pd
from pathlib import Path

print('Task 2: Multiple-Choice Questions (MCQ)')

reference_dir = Path('/app/input', 'ref')
prediction_dir = Path('/app/input', 'res')
score_dir = '/app/output'

print('Reading Data...')
# Note: The reference filename and extension are hardcoded here.
df_reference = pd.read_csv(Path(reference_dir, 'final_2_mcq_reference.tsv'), sep='\t')
df_reference['language_region'] = df_reference['id'].apply(lambda x: x.split('_')[0])

# TODO: Avoid hardcoding the prediction filename and use grep instead
df_prediction = pd.read_csv(Path(prediction_dir, 'prediction/track_2_mcq_prediction.tsv'), sep='\t')

# Check whether columns named id, A, B, C, D exist
if {'id', 'A', 'B', 'C', 'D'} - set(df_prediction.columns):
    raise ValueError(f"Prediction file must contain 'id', 'A', 'B', 'C', 'D' columns.")


def score(df_truth, df_pred, verbose=False):
    correct = 0

    if df_pred['id'].duplicated().any():
        print("Warning: Duplicate IDs found in predictions. Using the last occurrence for each ID:")
        print(df_pred[df_pred.duplicated(subset=['id'])]['id'].unique().tolist())
        df_pred = df_pred.drop_duplicates(subset='id', keep='last')
    
    # Pre-index predictions for O(1) lookup
    pred_map = df_pred.set_index('id')[['A', 'B', 'C', 'D']].to_dict(orient='index')

    for i, row_truth in df_truth.iterrows():
        qid = row_truth['id']

        if qid not in pred_map:
            if verbose: print(f"[{qid}] No prediction found.")
            continue

        row_pred = pred_map[qid]
        
        # Check A, B, C, D columns have binary values (0/1)
        if not all(x in [0, 1] for x in row_pred.values()):
            if verbose: print(f"[{qid}] Values other than 0 or 1 found.")
            continue
        
        # Check only one of A, B, C, D columns is 1
        if sum(row_pred.values()) != 1:
            if verbose: print(f"[{qid}] More than one or none of A, B, C, D columns are 1.")
            continue

        if row_pred[row_truth['answer']] == 1:
            correct += 1

    accuracy = 100 * correct / len(df_truth)
    return accuracy


print('Scoring...')
scores = {}
# Score for each language_region
for lang_region, group in df_reference.groupby('language_region'):
    df_ref_group = df_reference[df_reference['language_region'] == lang_region]
    scores[str(lang_region)] = score(df_ref_group, df_prediction, verbose=True)
# Overall score
unique_language_regions = df_reference['language_region'].unique()
scores['overall'] = sum(scores[str(language_region)] for language_region in unique_language_regions) / len(unique_language_regions)

print('Scores:')
print(json.dumps(scores, indent=4))

with open(str(Path(score_dir, 'scores.json')), 'w') as score_file:
    score_file.write(json.dumps(scores))
